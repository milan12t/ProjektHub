const express = require("express");
const multer = require("multer");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const app = express();
const PORT = 3001;
const JWT_SECRET = "projecthub_secret_2024_change_in_production";
const DB_FILE = path.join(__dirname, "db.json");
const UPLOADS_DIR = path.join(__dirname, "uploads");

app.use(cors({ origin: "http://localhost:5173", credentials: true }));
app.use(express.json());
app.use("/uploads", express.static(UPLOADS_DIR));

// ── Simple JSON "database" ───────────────────────────────────────────────────
function readDB() {
  try {
    if (!fs.existsSync(DB_FILE)) return { users: [], projects: [] };
    return JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
  } catch { return { users: [], projects: [] }; }
}
function writeDB(data) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

// ── Auth middleware ──────────────────────────────────────────────────────────
function authMiddleware(req, res, next) {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ error: "Niste prijavljeni" });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: "Nevažeći token" });
  }
}

// ── Multer storage — per-user folder ────────────────────────────────────────
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const userFolder = path.join(UPLOADS_DIR, req.user.folderName);
    fs.mkdirSync(userFolder, { recursive: true });
    cb(null, userFolder);
  },
  filename: (req, file, cb) => {
    const safe = file.originalname.replace(/[^a-zA-Z0-9._-]/g, "_");
    cb(null, safe);
  },
});
const upload = multer({ storage, limits: { fileSize: 100 * 1024 * 1024 } }); // 100MB limit

// ── ROUTES ───────────────────────────────────────────────────────────────────

// POST /api/register
app.post("/api/register", async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) return res.status(400).json({ error: "Sva polja su obavezna" });

  const db = readDB();
  if (db.users.find(u => u.email === email))
    return res.status(400).json({ error: "Email već postoji" });

  const folderName = name.toLowerCase().replace(/\s+/g, "_") + "_" + Math.random().toString(36).slice(2, 6);
  const userFolder = path.join(UPLOADS_DIR, folderName);
  fs.mkdirSync(userFolder, { recursive: true });

  const hashed = await bcrypt.hash(password, 10);
  const user = {
    id: Math.random().toString(36).slice(2, 10),
    name,
    email,
    password: hashed,
    folderName,
    folder: "/" + folderName,
    avatar: name.slice(0, 2).toUpperCase(),
    createdAt: new Date().toISOString(),
  };

  db.users.push(user);
  writeDB(db);

  const { password: _, ...safeUser } = user;
  const token = jwt.sign({ id: user.id, folderName: user.folderName }, JWT_SECRET, { expiresIn: "7d" });
  res.json({ user: safeUser, token });
});

// POST /api/login
app.post("/api/login", async (req, res) => {
  const { email, password } = req.body;
  const db = readDB();
  const user = db.users.find(u => u.email === email);
  if (!user) return res.status(401).json({ error: "Pogrešan email ili lozinka" });

  const ok = await bcrypt.compare(password, user.password);
  if (!ok) return res.status(401).json({ error: "Pogrešan email ili lozinka" });

  const { password: _, ...safeUser } = user;
  const token = jwt.sign({ id: user.id, folderName: user.folderName }, JWT_SECRET, { expiresIn: "7d" });
  res.json({ user: safeUser, token });
});

// GET /api/me
app.get("/api/me", authMiddleware, (req, res) => {
  const db = readDB();
  const user = db.users.find(u => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: "Korisnik nije pronađen" });
  const { password: _, ...safeUser } = user;
  res.json(safeUser);
});

// GET /api/projects
app.get("/api/projects", authMiddleware, (req, res) => {
  const db = readDB();
  res.json(db.projects.sort((a, b) => new Date(b.uploadedAt) - new Date(a.uploadedAt)));
});

// POST /api/projects  (multipart upload)
app.post("/api/projects", authMiddleware, upload.array("files"), (req, res) => {
  const { title, description, tags } = req.body;
  if (!title) return res.status(400).json({ error: "Naziv projekta je obavezan" });
  if (!req.files || req.files.length === 0) return res.status(400).json({ error: "Nema fajlova" });

  const db = readDB();
  const user = db.users.find(u => u.id === req.user.id);

  const project = {
    id: Math.random().toString(36).slice(2, 10),
    userId: user.id,
    userName: user.name,
    userFolder: user.folder,
    title,
    description: description || "",
    tags: tags ? tags.split(",").map(t => t.trim()).filter(Boolean) : [],
    files: req.files.map(f => ({
      id: Math.random().toString(36).slice(2, 8),
      name: f.originalname,
      filename: f.filename,
      size: f.size,
      mimetype: f.mimetype,
      url: `/uploads/${user.folderName}/${f.filename}`,
    })),
    totalSize: req.files.reduce((s, f) => s + f.size, 0),
    path: `/${user.folderName}/${title.replace(/\s+/g, "_").toLowerCase()}`,
    uploadedAt: new Date().toISOString(),
  };

  db.projects.push(project);
  writeDB(db);
  res.json(project);
});

// DELETE /api/projects/:id
app.delete("/api/projects/:id", authMiddleware, (req, res) => {
  const db = readDB();
  const idx = db.projects.findIndex(p => p.id === req.params.id && p.userId === req.user.id);
  if (idx === -1) return res.status(404).json({ error: "Projekat nije pronađen" });

  // Delete actual files
  const project = db.projects[idx];
  project.files.forEach(f => {
    const filePath = path.join(UPLOADS_DIR, req.user.folderName, f.filename);
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
  });

  db.projects.splice(idx, 1);
  writeDB(db);
  res.json({ ok: true });
});

// GET /api/users/count
app.get("/api/users/count", authMiddleware, (req, res) => {
  const db = readDB();
  res.json({ count: db.users.length });
});

app.listen(PORT, () => {
  console.log(`\n🚀 ProjectHub server pokrenut na http://localhost:${PORT}`);
  console.log(`📁 Upload folder: ${UPLOADS_DIR}\n`);
});
